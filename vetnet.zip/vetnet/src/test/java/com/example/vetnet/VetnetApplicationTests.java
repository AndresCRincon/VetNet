package com.example.vetnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetnetApplicationTests {

	@Test
	void contextLoads() {
	}

}
